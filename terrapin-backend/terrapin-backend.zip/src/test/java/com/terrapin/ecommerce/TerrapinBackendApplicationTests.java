package com.terrapin.ecommerce;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TerrapinBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
