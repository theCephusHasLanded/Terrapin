package com.terrapin.ecommerce;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TerrapinBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(TerrapinBackendApplication.class, args);
	}

}
